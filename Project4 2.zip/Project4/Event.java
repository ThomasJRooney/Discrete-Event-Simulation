// Priority Queue and Simulation
// Event is the generic interface for a runnable agenda object.

public interface Event {

    void run();

}